package com.example.springbootexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootexampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
