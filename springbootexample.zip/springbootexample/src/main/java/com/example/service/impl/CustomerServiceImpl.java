package com.example.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.entities.Customer;
import com.example.repository.CustomerRepository;
import com.example.service.CustomerService;

import jakarta.websocket.server.ServerEndpoint;
@Service

public class CustomerServiceImpl implements CustomerService {
	
	private CustomerRepository customerRepository;
    public CustomerServiceImpl(CustomerRepository customerRepository) {
		
		this.customerRepository = customerRepository;
	}
	

	@Override
	public List<Customer> getAll() {
		// TODO Auto-generated method stub
		System.out.println("Hello==============================");
		return customerRepository.findAll();
	}

	

	@Override
	public Customer getById(int id) {
		// TODO Auto-generated method stub
		return customerRepository.findById(id).get();
	}

	@Override
	public String add(Customer customer) {
		// TODO Auto-generated method stub
     customerRepository.save(customer);
     return "Customer saved";
	}

	@Override
	public String update(Customer customer) {
		// TODO Auto-generated method stub
		customerRepository.save(customer);
		
		return "Customer Added Successfully";
	}

	@Override
	public String delete(int id) {
		// TODO Auto-generated method stub
		customerRepository.deleteById(id);
		
		return "Employee Deleted Successfully";
	}

}
