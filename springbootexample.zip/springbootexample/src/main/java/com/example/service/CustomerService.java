package com.example.service;

import java.util.List;

import com.example.entities.Customer;

public interface CustomerService {
    List<Customer> getAll();
    Customer getById(int id);
    String add(Customer customer);
    String update(Customer customer);
    String delete(int id);

}

