package com.example.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.entities.Customer;
import com.example.service.CustomerService;



@Controller

public class CustomerController {
	private CustomerService customerService;

	public CustomerController(CustomerService customerService) {
		
		this.customerService = customerService;
	}
	//@RequestMapping(path="/",method=RequestMethod.GET)
	// url
	@GetMapping("/hello")
	public String getAll(Model model) {
		List<Customer> customer =customerService.getAll();
		System.out.println("Customers "+customer);
		System.out.println("====================================================");
		model.addAttribute("customer",customer);
		return "index";
	
		
		
	}
	@GetMapping("/hello")
	public String test(){
		return "hello";
	}
	

}
