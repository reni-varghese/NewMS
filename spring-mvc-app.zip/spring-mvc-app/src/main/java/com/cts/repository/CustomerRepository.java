package com.cts.repository;

import java.util.List;

import com.cts.model.Customer;

public interface CustomerRepository {
	List<Customer> getAll();
	Customer getById(int id);
	void addCustomer(Customer customer);
	void updateCustomer(Customer customer);
	void deleteCustomer(int id);
	
	
}
