package com.cts.service;

import java.util.List;

import com.cts.model.Customer;

public interface CustomerService {
	List<Customer> getAll();
	Customer getById(int id);
	void addCustomer(Customer customer);
	void updateCustomer(Customer customer);
	void deleteCustomer(int id);
}
