package com.cts.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cts.service.CustomerService;

@Controller
public class CustomerController {
	
	@Autowired
	private CustomerService customerService;
	
	@GetMapping("/")
	public ModelAndView getAll() {
		var customers = customerService.getAll();
		ModelAndView mv = new ModelAndView("index");
		mv.addObject("customers",customers);
		return mv;
	}
}
